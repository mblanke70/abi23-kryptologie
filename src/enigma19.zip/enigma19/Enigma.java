package enigma19;

public class Enigma 
{	
	public static final Rotor right = new Rotor("BDFHJLCPRTXVZNYEIWGAKMUSQO", 21);	// Rotor 3
	public static final Rotor mid   = new Rotor("AJDKSIRUXBLHWTMCQGZNPYFVOE", 4);	// Rotor 2
	public static final Rotor left  = new Rotor("EKMFLGDQVZNTOWYHXUSPAIBRCJ", 16);	// Rotor 1
	public static final Rotor refl  = new Rotor("YRUHQSLDPXNGOKMIEBFZCWVJAT", -1);	// Reflektor B
			
	public void step()
	{
		right.step();
		
		if( right.getPos() == right.getCarryPos()+1 )
		{
			mid.step();
			if( mid.getPos() == mid.getCarryPos()+1 ) 
			{
				left.step();
			}
		}
	}
	
	public String toString()
	{
		String c = "";
		
		c += (char) (left. getPos() + 65); 
		c += (char) (mid.  getPos() + 65); 
		c += (char) (right.getPos() + 65); 
		
		return c;
	}
	
	public char encrypt(char c)
	{
		step();

		System.out.println(this);

		c = right.encrypt(c, 0);
		c = mid.  encrypt(c, 0);
		c = left. encrypt(c, 0);
		c = refl. encrypt(c, 0);
		c = left. encrypt(c, 1);
		c = mid.  encrypt(c, 1);
		c = right.encrypt(c, 1);

		return c;
	}
	
	public String encrypt(String plain)
	{
		String cipher = "";
		for(int i=0; i<plain.length(); i++)
		{
			cipher += encrypt(plain.charAt(i));
		}
		
		return cipher;
	}
	
	public static void main(String[] args) 
	{
		Enigma enigma = new Enigma();
		
		String cipher = enigma.encrypt("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println(cipher);
	}
}